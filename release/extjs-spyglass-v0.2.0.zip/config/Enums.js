export default {
  msgType: {
    getCmpId: 'getCmpId',
  },
};
